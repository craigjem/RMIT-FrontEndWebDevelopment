# Landing Page Project

CJ Technical Blog

## Table of Contents

* [Instructions](#instructions)

## Instructions

CJ Technical Blog is a dynamically built website realying on the app.js javascript file which dynamically builds the navigation menu system of the site, allowing scrolling and highlighting of the menu system and content headings so the end users can understand and successfully navigate the web site application.


## Dependencies

There is only one depend file for this project app.js which is found in the js folder, when downloading the project ensure the js folder and app.js file is included with the project


